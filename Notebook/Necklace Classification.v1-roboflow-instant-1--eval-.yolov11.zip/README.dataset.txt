# Necklace Classification > Roboflow Instant 1 [Eval]
https://universe.roboflow.com/od-r3uad/necklace-classification-jkkee

Provided by a Roboflow user
License: CC BY 4.0

